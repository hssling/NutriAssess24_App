package com.simsrh.nutriassess24.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.simsrh.nutriassess24.data.entities.FoodItem
import com.simsrh.nutriassess24.data.repo.NutriRepository
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

@Composable
fun FoodSearch(onSelect: (FoodItem) -> Unit) {
    var q by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    var results by remember { mutableStateOf(listOf<FoodItem>()) }

    Column {
        OutlinedTextField(q, onValueChange = {
            q = it
            scope.launch {
                NutriRepository.searchFoods(q).collectLatest { results = it }
            }
        }, modifier = Modifier.fillMaxWidth(), label = { Text("Search food") })
        Spacer(Modifier.height(6.dp))
        results.take(12).forEach { f ->
            ElevatedButton(onClick = { onSelect(f) }, modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                Text(f.name + (f.localName?.let { " / $it" } ?: ""))
            }
        }
    }
}
