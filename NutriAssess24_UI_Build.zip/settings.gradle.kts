rootProject.name = "NutriAssess24"
include(":app")
