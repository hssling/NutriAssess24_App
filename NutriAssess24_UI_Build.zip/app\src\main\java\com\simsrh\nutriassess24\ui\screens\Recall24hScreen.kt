package com.simsrh.nutriassess24.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.simsrh.nutriassess24.ui.components.FoodSearch
import com.simsrh.nutriassess24.ui.components.NumberStepper
import com.simsrh.nutriassess24.data.entities.FoodItem

data class MealItem(val food: FoodItem, var qty: Double)

@Composable
fun Recall24hScreen(onDone: () -> Unit) {
    val meals = listOf("early_morning","breakfast","mid_morning","lunch","evening","dinner","bedtime")
    val state = remember { meals.associateWith { mutableStateListOf<MealItem>() }.toMutableMap() }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("24-Hour Recall", style = MaterialTheme.typography.headlineSmall)
        meals.forEach { slot ->
            Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text(slot.replaceFirstChar { it.titlecase() }, style = MaterialTheme.typography.titleMedium)
                    FoodSearch { food -> state[slot]!!.add(MealItem(food, 100.0)) }
                    state[slot]!!.forEach { item ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(item.food.name)
                            NumberStepper(item.qty) { item.qty = it }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Button(onClick = onDone, modifier = Modifier.fillMaxWidth()) { Text("Calculate") }
    }
}
