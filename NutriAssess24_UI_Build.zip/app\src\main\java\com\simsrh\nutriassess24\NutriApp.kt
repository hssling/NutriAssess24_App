package com.simsrh.nutriassess24

import android.app.Application
import androidx.room.Room
import com.simsrh.nutriassess24.data.db.NutriDatabase

class NutriApp : Application() {
    companion object {
        lateinit var db: NutriDatabase
            private set
    }
    override fun onCreate() {
        super.onCreate()
        db = Room.databaseBuilder(this, NutriDatabase::class.java, "nutri.db")
            .createFromAsset("databases/nutri_seed.db")
            .fallbackToDestructiveMigration()
            .build()
    }
}
