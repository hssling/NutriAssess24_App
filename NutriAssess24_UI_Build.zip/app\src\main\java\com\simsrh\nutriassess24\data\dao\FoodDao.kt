package com.simsrh.nutriassess24.data.dao

import androidx.room.*
import com.simsrh.nutriassess24.data.entities.FoodItem
import kotlinx.coroutines.flow.Flow

@Dao
interface FoodDao {
    @Query("SELECT * FROM foods WHERE name LIKE '%' || :q || '%' OR localName LIKE '%' || :q || '%' ORDER BY name LIMIT 200")
    fun search(q: String): Flow<List<FoodItem>>
}
