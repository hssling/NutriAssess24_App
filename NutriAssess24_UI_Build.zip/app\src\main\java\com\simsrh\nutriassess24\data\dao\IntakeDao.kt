package com.simsrh.nutriassess24.data.dao

import androidx.room.*
import com.simsrh.nutriassess24.data.entities.IntakeEntry
import kotlinx.coroutines.flow.Flow

@Dao
interface IntakeDao {
    @Query("SELECT * FROM intakes WHERE profileId=:pid ORDER BY timestamp")
    fun forProfile(pid: Long): Flow<List<IntakeEntry>>

    @Insert
    suspend fun insert(e: IntakeEntry)

    @Query("DELETE FROM intakes WHERE profileId=:pid")
    suspend fun clearFor(pid: Long)
}
