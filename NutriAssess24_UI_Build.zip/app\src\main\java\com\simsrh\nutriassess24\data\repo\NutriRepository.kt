package com.simsrh.nutriassess24.data.repo

import com.simsrh.nutriassess24.NutriApp
import com.simsrh.nutriassess24.data.entities.*

object NutriRepository {
    private val db get() = NutriApp.db
    fun searchFoods(q: String) = db.food().search(q)
    fun intakesFor(pid: Long) = db.intake().forProfile(pid)
    suspend fun addIntake(e: IntakeEntry) = db.intake().insert(e)
    fun profiles() = db.profile().all()
    suspend fun addProfile(p: PersonProfile) = db.profile().insert(p)
    suspend fun clearIntakes(pid: Long) = db.intake().clearFor(pid)
}
