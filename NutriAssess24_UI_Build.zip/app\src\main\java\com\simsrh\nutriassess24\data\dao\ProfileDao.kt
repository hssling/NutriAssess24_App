package com.simsrh.nutriassess24.data.dao

import androidx.room.*
import com.simsrh.nutriassess24.data.entities.PersonProfile
import kotlinx.coroutines.flow.Flow

@Dao
interface ProfileDao {
    @Query("SELECT * FROM profiles ORDER BY id DESC")
    fun all(): Flow<List<PersonProfile>>

    @Insert
    suspend fun insert(p: PersonProfile)
}
