package com.simsrh.nutriassess24.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.res.stringResource
import com.simsrh.nutriassess24.R

@Composable
fun SummaryScreen(onAdvice: () -> Unit, onRefs: () -> Unit, onExportCsv: () -> Unit, onExportPdf: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(stringResource(R.string.summary), style = MaterialTheme.typography.headlineSmall)
        Text("Energy/Protein/Fat and micronutrient totals vs targets (placeholder).")
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onAdvice, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.advice)) }
            OutlinedButton(onClick = onRefs, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.references)) }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = onExportCsv, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.export_csv)) }
        OutlinedButton(onClick = onExportPdf, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.export_pdf)) }
    }
}
