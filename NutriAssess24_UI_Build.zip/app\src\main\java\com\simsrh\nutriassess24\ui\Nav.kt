package com.simsrh.nutriassess24.ui

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.rememberNavController
import androidx.navigation.compose.composable
import com.simsrh.nutriassess24.ui.screens.*

@Composable
fun NutriNavHost() {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = "profile") {
        composable("profile") { ProfileScreen(onNext = { nav.navigate("methodPicker") }) }
        composable("methodPicker") { MethodPickerScreen(
            onRecall = { nav.navigate("recall") },
            onAnthro = { nav.navigate("anthro") },
            onClinical = { nav.navigate("clinical") }) }
        composable("recall") { Recall24hScreen(onDone = { nav.navigate("summary") }) }
        composable("summary") { SummaryScreen(
            onAdvice = { nav.navigate("advice") },
            onRefs = { nav.navigate("refs") },
            onExportCsv = { nav.navigate("exportCsv") },
            onExportPdf = { nav.navigate("exportPdf") }
        ) }
        composable("advice") { DeficitAdviceScreen(onDone = { nav.popBackStack("profile", false) }) }
        composable("refs") { ReferencesScreen() }
        composable("anthro") { AnthropometryScreen(onBack = { nav.popBackStack() }) }
        composable("clinical") { ClinicalSignsScreen(onBack = { nav.popBackStack() }) }
        composable("exportCsv") { ExportCsvScreen(onBack = { nav.popBackStack() }) }
        composable("exportPdf") { ExportPdfScreen(onBack = { nav.popBackStack() }) }
    }
}
