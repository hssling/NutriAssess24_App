package com.simsrh.nutriassess24.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "profiles")
data class PersonProfile(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val sex: String,
    val ageYears: Int,
    val weightKg: Double,
    val heightCm: Double,
    val activity: String,
    val physiological: String? = null
)
