package com.simsrh.nutriassess24.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "intakes")
data class IntakeEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileId: Long,
    val timestamp: Long,
    val mealSlot: String,
    val foodId: Long,
    val qtyGrams: Double,
    val recipeJson: String? = null
)
