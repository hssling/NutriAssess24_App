package com.simsrh.nutriassess24.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "foods")
data class FoodItem(
    @PrimaryKey val id: Long,
    val name: String,
    val localName: String? = null,
    val group_name: String? = null,
    val edibleFraction: Double = 1.0,
    val energyKcal: Double,
    val proteinG: Double,
    val fatG: Double,
    val carbohydrateG: Double?,
    val fiberG: Double?,
    val ironMg: Double?,
    val calciumMg: Double?,
    val vitaminCMg: Double?,
    val folateMcg: Double?,
    val vitaminAMcg: Double?,
    val zincMg: Double?,
    val thiamineMg: Double?,
    val riboflavinMg: Double?,
    val niacinMg: Double?,
    val vitB6Mg: Double?,
    val vitB12Mcg: Double?
)
