package com.simsrh.nutriassess24.domain

import com.simsrh.nutriassess24.data.entities.FoodItem
import com.simsrh.nutriassess24.data.entities.PersonProfile
import kotlin.math.max

class NutritionCalculator(private val rda: RdaRoot) {

    data class Totals(
        val energyKcal: Double, val proteinG: Double, val fatG: Double,
        val carbsG: Double?, val fiberG: Double?, val micronutrients: Map<String, Double>
    )

    fun sumIntake(entries: List<Pair<FoodItem, Double>>): Totals {
        var e = 0.0; var p = 0.0; var f = 0.0; var c: Double? = 0.0; var fi: Double? = 0.0
        val micro = mutableMapOf<String, Double>()
        fun add(name: String, v: Double?) { if (v != null) micro[name] = (micro[name] ?: 0.0) + v }

        entries.forEach { (food, grams) ->
            val factor = grams / 100.0 * food.edibleFraction
            e += food.energyKcal * factor
            p += food.proteinG * factor
            f += food.fatG * factor
            c = c?.let { base -> food.carbohydrateG?.let { base + it * factor } }
            fi = fi?.let { base -> food.fiberG?.let { base + it * factor } }
            add("iron_mg", food.ironMg?.times(factor))
            add("calcium_mg", food.calciumMg?.times(factor))
            add("vitamin_c_mg", food.vitaminCMg?.times(factor))
            add("folate_mcg", food.folateMcg?.times(factor))
            add("vitamin_a_mcg", food.vitaminAMcg?.times(factor))
            add("zinc_mg", food.zincMg?.times(factor))
            add("thiamine_mg", food.thiamineMg?.times(factor))
            add("riboflavin_mg", food.riboflavinMg?.times(factor))
            add("niacin_mg", food.niacinMg?.times(factor))
            add("vit_b6_mg", food.vitB6Mg?.times(factor))
            add("vit_b12_mcg", food.vitB12Mcg?.times(factor))
        }
        return Totals(e, p, f, c, fi, micro)
    }

    data class Targets(
        val energyKcal: Double, val proteinG: Double, val fatG: Double,
        val micronutrients: Map<String, Double>
    )

    fun targetsFor(profile: PersonProfile): Targets {
        val sexKey = if (profile.sex.lowercase().startsWith("f")) "adult_female" else "adult_male"
        val base = rda.groups[sexKey]?.get(profile.activity) ?: RdaRoot.MacroTargets(2000.0, 0.83, 40.0, null, null)
        var energy = (base.energy_kcal ?: 0.0)
        var prot = profile.weightKg * base.protein_g_per_kg
        var fat  = (base.fat_g ?: 0.0)

        val micro = mutableMapOf<String, Double>()
        rda.micronutrients.forEach { (k, vmap) ->
            micro[k] = vmap[sexKey] ?: vmap["adult"] ?: 0.0
        }

        base.extra_energy_kcal?.let { energy += it }
        base.extra_protein_g?.let { prot += it }
        return Targets(energy, prot, fat, micro)
    }

    data class Deficits(val energy: Double, val protein: Double, val fat: Double, val micro: Map<String, Double>)

    fun deficits(totals: Totals, targets: Targets): Deficits {
        fun d(x: Double, y: Double) = max(0.0, y - x)
        val microDef = targets.micronutrients.mapValues { (k, v) -> max(0.0, v - (totals.micronutrients[k] ?: 0.0)) }
        return Deficits(d(totals.energyKcal, targets.energyKcal), d(totals.proteinG, targets.proteinG), d(totals.fatG, targets.fatG), microDef)
    }
}
