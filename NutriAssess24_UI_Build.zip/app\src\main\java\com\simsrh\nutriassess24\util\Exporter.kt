package com.simsrh.nutriassess24.util

import android.content.Context
import java.io.File

object Exporter {
    fun exportCsv(ctx: Context, rows: List<Pair<String,String>>): String {
        val f = File(ctx.filesDir, "nutri_summary.csv")
        f.printWriter().use { pw ->
            pw.println("metric,value")
            rows.forEach { (k,v) -> pw.println("$k,$v") }
        }
        return f.absolutePath
    }
}
