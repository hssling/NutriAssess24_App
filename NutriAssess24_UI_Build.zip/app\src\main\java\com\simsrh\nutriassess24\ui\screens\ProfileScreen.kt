package com.simsrh.nutriassess24.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.res.stringResource
import com.simsrh.nutriassess24.R
import com.simsrh.nutriassess24.data.entities.PersonProfile
import com.simsrh.nutriassess24.data.repo.NutriRepository
import kotlinx.coroutines.launch

@Composable
fun ProfileScreen(onNext: () -> Unit) {
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("Patient") }
    var sex by remember { mutableStateOf("male") }
    var age by remember { mutableStateOf("30") }
    var wt by remember { mutableStateOf("70") }
    var ht by remember { mutableStateOf("170") }
    var activity by remember { mutableStateOf("moderate") }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(text = stringResource(R.string.profile), style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(name, { name = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(sex, { sex = it }, label = { Text("Sex (male/female)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(age, { age = it }, label = { Text("Age (years)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(wt, { wt = it }, label = { Text("Weight (kg)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(ht, { ht = it }, label = { Text("Height (cm)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(activity, { activity = it }, label = { Text("Activity (sedentary/moderate/heavy)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        Button(onClick = {
            scope.launch {
                NutriRepository.addProfile(PersonProfile(0, name, sex, age.toIntOrNull()?:30, wt.toDoubleOrNull()?:70.0, ht.toDoubleOrNull()?:170.0, activity, null))
                onNext()
            }
        }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.continue_txt)) }
    }
}
