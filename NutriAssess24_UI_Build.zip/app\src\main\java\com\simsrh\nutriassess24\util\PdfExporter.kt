package com.simsrh.nutriassess24.util

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream

object PdfExporter {
    fun exportSummaryPdf(ctx: Context, title: String, lines: List<String>): String {
        val doc = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = doc.startPage(pageInfo)
        val canvas: Canvas = page.canvas
        val paint = Paint().apply { textSize = 14f }
        var y = 40f
        canvas.drawText(title, 40f, y, paint)
        y += 24f
        lines.forEach {
            canvas.drawText(it, 40f, y, paint)
            y += 18f
        }
        doc.finishPage(page)
        val outFile = File(ctx.filesDir, "nutri_summary.pdf")
        FileOutputStream(outFile).use { doc.writeTo(it) }
        doc.close()
        return outFile.absolutePath
    }
}
