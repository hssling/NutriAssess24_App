package com.simsrh.nutriassess24.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import com.simsrh.nutriassess24.util.PdfExporter

@Composable
fun ExportPdfScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var path by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Export PDF", style = MaterialTheme.typography.headlineSmall)
        Button(onClick = { path = PdfExporter.exportSummaryPdf(ctx, "Nutrition Summary",
            listOf("Energy: 2100 kcal","Protein: 54 g","Fat: 45 g","Micros within range: demo")) }, modifier = Modifier.fillMaxWidth()) {
            Text("Export PDF")
        }
        path?.let { Text("Saved: " + it) }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Back") }
    }
}
