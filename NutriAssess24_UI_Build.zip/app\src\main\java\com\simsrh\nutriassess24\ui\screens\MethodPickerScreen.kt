package com.simsrh.nutriassess24.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.res.stringResource
import com.simsrh.nutriassess24.R

@Composable
fun MethodPickerScreen(onRecall: () -> Unit, onAnthro: () -> Unit, onClinical: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(stringResource(R.string.select_method), style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(16.dp))
        Button(onClick = onRecall, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.recall_24h)) }
        OutlinedButton(onClick = onAnthro, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.anthropometry)) }
        OutlinedButton(onClick = onClinical, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.clinical_signs)) }
    }
}
