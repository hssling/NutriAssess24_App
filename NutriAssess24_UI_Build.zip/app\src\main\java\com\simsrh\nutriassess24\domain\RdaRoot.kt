package com.simsrh.nutriassess24.domain

import kotlinx.serialization.Serializable

@Serializable
data class RdaRoot(
    val groups: Map<String, Map<String, MacroTargets>>,
    val micronutrients: Map<String, Map<String, Double>>
) {
    @Serializable data class MacroTargets(
        val energy_kcal: Double? = null,
        val protein_g_per_kg: Double = 0.83,
        val fat_g: Double? = null,
        val extra_energy_kcal: Double? = null,
        val extra_protein_g: Double? = null
    )
}
