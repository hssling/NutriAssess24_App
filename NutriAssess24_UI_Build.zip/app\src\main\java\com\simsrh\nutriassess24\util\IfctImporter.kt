package com.simsrh.nutriassess24.util

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.util.Log
import com.opencsv.CSVReader
import java.io.InputStreamReader

object IfctImporter {
    fun importFromAssets(ctx: Context, db: SQLiteDatabase): Int {
        return try {
            val ins = ctx.assets.open("ifct_full.csv")
            val reader = CSVReader(InputStreamReader(ins))
            reader.readNext() // header
            var row = reader.readNext()
            var n = 0
            db.beginTransaction()
            db.execSQL("DELETE FROM foods")
            val stmt = db.compileStatement("""
                INSERT INTO foods(id,name,localName,group_name,edibleFraction,energyKcal,proteinG,fatG,carbohydrateG,fiberG,ironMg,calciumMg,vitaminCMg,folateMcg,vitaminAMcg,zincMg,thiamineMg,riboflavinMg,niacinMg,vitB6Mg,vitB12Mcg)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """.trimIndent())
            while (row != null) {
                for ((i,v) in row.withIndex()) stmt.bindString(i+1, if (v.isBlank()) "0" else v)
                stmt.executeInsert()
                stmt.clearBindings()
                row = reader.readNext()
                n++
            }
            db.setTransactionSuccessful()
            db.endTransaction()
            n
        } catch (e: Exception) {
            Log.e("IfctImporter", "Import failed: ${e.message}")
            0
        }
    }
}
