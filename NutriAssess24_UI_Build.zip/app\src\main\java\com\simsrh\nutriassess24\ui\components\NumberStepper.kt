package com.simsrh.nutriassess24.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun NumberStepper(value: Double, onChange: (Double) -> Unit, suffix: String = "g") {
    Row(verticalAlignment = Alignment.CenterVertically) {
        OutlinedButton(onClick = { onChange((value - 10).coerceAtLeast(0.0)) }) { Text("-") }
        Text("%.0f %s".format(value, suffix), modifier = Modifier.padding(horizontal = 12.dp))
        OutlinedButton(onClick = { onChange(value + 10) }) { Text("+") }
    }
}
