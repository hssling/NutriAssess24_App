package com.simsrh.nutriassess24.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun ClinicalSignsScreen(onBack: () -> Unit) {
    val signs = listOf(
        "Bitot’s spots (Vit A)", "Angular stomatitis (B2)", "Glossitis (B complex)",
        "Pallor (Iron)", "Pedal edema (Protein)", "Scurvy signs (Vit C)"
    )
    val checked = remember { signs.associateWith { mutableStateOf(false) } }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Clinical Signs", style = MaterialTheme.typography.headlineSmall)
        signs.forEach { s ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(s); Checkbox(checked = checked[s]!!.value, onCheckedChange = { checked[s]!!.value = it })
            }
        }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Back") }
    }
}
