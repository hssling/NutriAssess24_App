package com.simsrh.nutriassess24.data.db

import androidx.room.Database
import androidx.room.RoomDatabase
import com.simsrh.nutriassess24.data.dao.*
import com.simsrh.nutriassess24.data.entities.*

@Database(
    entities = [FoodItem::class, IntakeEntry::class, PersonProfile::class],
    version = 1
)
abstract class NutriDatabase : RoomDatabase() {
    abstract fun food(): FoodDao
    abstract fun intake(): IntakeDao
    abstract fun profile(): ProfileDao
}
